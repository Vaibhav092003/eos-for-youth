<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require 'vendor/autoload.php';


if(isset($_POST['applicant-email'])){
    $message1='
        
    	<table width="100%" border="0" cellspacing="0" cellpadding="0" style="border-collapse: collapse;">
  <tbody>
    <tr>
      <td width="15%" align="left" height="30px" style="border: 1px solid #CCCCCC; padding-left:10px;"><strong>Name</strong> :</td>
      <td width="85%" align="left" style="border: 1px solid #CCCCCC; padding-left:10px"><strong>'.$_POST['applicant-name'].'</strong></td>
    </tr>
    <tr>
      <td align="left" height="30px" style="border: 1px solid #CCCCCC; padding-left:10px"><strong>Age</strong> : </td>
      <td align="left" style="border: 1px solid #CCCCCC; padding-left:10px"><strong>'.$_POST['applicant-age'].'</strong></td>
    </tr>
    <tr>
      <td align="left" height="30px" style="border: 1px solid #CCCCCC; padding-left:10px"><strong>Email</strong> :</td>
      <td align="left" style="border: 1px solid #CCCCCC; padding-left:10px"><strong>'.$_POST['applicant-email'].'</strong></td>
    </tr>
    <tr>
      <td align="left" height="30px" style="border: 1px solid #CCCCCC; padding-left:10px;"><strong>Phone</strong> :</td>
      <td style="border: 1px solid #CCCCCC; padding-left:10px;"><strong>'.$_POST['applicant-number'].'</strong></td>
    </tr>
    <tr>
      <td align="left" height="30px" style="border: 1px solid #CCCCCC; padding-left:10px;"><strong>Profession</strong> :</td>
      <td align="left" style="border: 1px solid #CCCCCC; padding-left:10px;"><strong>'.$_POST['applicant-profession'].'</strong></td>
    </tr>
    <tr>
      <td align="left" height="30px" style="border: 1px solid #CCCCCC; padding-left:10px;"><strong>Message</strong> :</td>
      <td align="left" style="border: 1px solid #CCCCCC; padding-left:10px;"><strong>'.$_POST['message'].'</strong></td>
    </tr>
  </tbody>
</table>
    ';
    //ini_set( 'display_errors', 1 );
    //error_reporting( E_ALL );
    
    $to='contact@skc.world';
    /*$subject = "Anaavaran Workshop registration initiated";
    $message="testing mail";
    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
    $headers .= 'From: <noreply@skc.world>' . "\r\n";
    $headers .= 'Bcc: avdhesh@detecvision.com' . "\r\n";
    
    if(mail($to,$subject,$message1, $headers)){
        //echo "send success";
    }else{
       // echo "something errors";
    }*/
    
    
    $mail = new PHPMailer();
    try {
        //Server settings
        $mail->SMTPDebug = 0; // Enable verbose debug output
        $mail->isSMTP(); 
        
        // Set mailer to use SMTP
        $mail->Host       = 'skc.world';  // Specify main and backup SMTP servers
        $mail->SMTPAuth   = true; // Enable SMTP authentication
        
        $mail->Username = "noreply1@skc.world"; // SMTP username
        $mail->Password = "Noreply@123"; // SMTP password
        $mail->From = "noreply1@skc.world"; //do NOT fake header. The Username domain and the from domain must be the same.
        $mail->FromName = "SKC";
        //Recipients
        //$mail->setFrom('noreply@skc.world', 'SKC WORLD');
       // $mail->addAddress('vivek.kumar@detecvision.com');     //$to Add a recipient
        $mail->addAddress('contact@skc.world');     // Add a recipient
        $mail->addBCC('avdhesh@detecvision.com');
        //$mail->addBCC('vivek.kumar@detecvision.com');
       // $mail->addReplyTo('contact@skc.world', 'SKC WORLD');
        $mail->isHTML(true);                                  // Set email format to HTML
        $mail->Subject = 'Anaavaran Workshop registration initiated';
        $mail->Body    = $message1;
        $mail->send();
        
       
        //echo 'Message has been sent';
        //echo json_encode(array('message'=>'Message has been sent' ,'class'=>'success-msg'));
       // echo 'Message has been sent';
    } catch (Exception $e) {
        //echo json_encode(array('message'=>'Message could not be sent' ,'class'=>'error-msg'));
        echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
    }
    
}else{
    header('location:https://www.skc.world/anaavaran-workshop');
}

?>
<!DOCTYPE html>
<html class="no-js">

<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Welcome to Anaavaran Workshop</title>
    <link rel=icon href='img/favicon.png' type='image/x-icon'/>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="css/custom.css?=v1.2">
    <link rel="stylesheet" href="css/flexboxgrid.css?=v1.1">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:300,400,600,700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=PT+Sans:400,600&display=swap" rel="stylesheet">
</head>

<body>

    <!-- top section -->
    <section class="banner-wraper t_price_banner other-page">
        <div class="container-fluid">
            <!-- logo and social icon section -->
            <div class="row ptop" style="display:none;">
                <div class="col-lg-6 col-sm-6 col-sm-12 col-xs-12">
                    <div class="anaavar-logo-box ">
                        <a href="index.html">ANAAVARAN</a>
                        <h3 class="fw600">PEEL Away the layers , discover the self</h3>
                    </div>
                </div>
            </div>
            <!-- banner section -->
        </div>
    </section>

    <!-- top  section -->

    <!-- first body section -->
   
    <section id="summary">
        <div class="workshop-details workshop-pad-top">
           <div class="container-fluid wrap">
                 <div id="Book-div" >
                      <div class="workshop-wrapper">
                      <div class="row work-detail-hding">
                        <div class="col-lg-12 col-sm-12 col-sm-12 col-xs-12">
                            <div>Ticket Type</div>
                        </div>
                        </div>
                        <div class="row ticket-chakar">
                        <div class="col-lg-4 col-sm-4 col-sm-12 col-xs-12">
                            <div class="anaavaran-quote">
                                <h2>
                                    Congratulations! You have submitted your interest for the Happiness Experiment (Anaavaran Workshop). Please make the payment to confirm your seat.
                                </h2>
                            </div>
                          <!--<img src="img/workshop-img-form.jpg" class="samarth-right-img img-responsive hidden-sm hidden-xs">-->
                        </div>
                        <div class="col-lg-8 col-sm-8 col-sm-12 col-xs-12">
                          <div class="ticket-detail-div">
                            <div class="detail-list">
                              <table  cellpadding="0" width="100%" cellspacing="0" border="0" class="workshop-details-table  mb0 mt0">
                                <tbody>
                                    <tr>
                                      <td><h3 class="detail-sub-hdings">Ticket Price</h3></td>
                                      <td><div id="TicketTypePrice" class="price-box"><span>19,500/-</span></div> 
                                      </td>
                                   </tr>
                                   <tr>
                                      <td><h3 class="detail-sub-hdings">No. Of Ticket</h3></td>
                                      <td><!--<div class="price-box"><span>30,000/-</span></div>-->
                                         <div class="list-items">
                                            <select id="dropdown" class="NoOfTicket" name="NoOfTicket" required>
                                               <!--<option value="">---Select---</option>-->
                                               <option value="1">01</option>
                                               <option value="2">02</option>
                                               <option value="3">03</option>
                                               <option value="4">04</option>
                                               <option value="5">05</option>
                                               <option value="6">06</option>
                                               <option value="7">07</option>
                                               <option value="8">08</option>
                                               <option value="9">09</option>
                                               <option value="10">10</option>
                                               <option value="11">11</option>
                                            </select>
                                         </div>
                                      </td>
                                    </tr>                       
                                </tbody>
                              </table>
                            </div>
                            <div class="detail-list list-border-none">
                              <table  cellpadding="0"  cellspacing="0" width="100%" border="0" class="workshop-details-table   price-total mb0 mt0">
                                <tbody>
                                  <tr>
                                    <td><h3 class="detail-sub-hdings">Sub Total <span>Inclusive of all Taxes (Non Residential Workshop)</span></h3></td>
                                    <td class="total-div" style="text-align: right;">
                                          <div class="total"></div>
                                          <div class="price-box"><span>19,500/-</span></div> 
                                    </td>
                                  </tr>
                                </tbody>
                              </table>
                              
                             
                        <form method="post" action="booknow.php">
                            <input type="hidden" name="ticket" value="1" id="fticket">
                            <input type="hidden" name="ticket_type" value="General" id="ticket_type">
                            <input type="hidden" name="price" value="19,500" id="price">
                            <input type="hidden" name="price2" value="19,500" id="total">
                            
                            <input type="hidden" name="name" value="<?=@$_POST['applicant-name']?>" >
                            <input type="hidden" name="age" value="<?=@$_POST['applicant-age']?>" >
                            <input type="hidden" name="email" value="<?=@$_POST['applicant-email']?>" >
                            <input type="hidden" name="number" value="<?=@$_POST['applicant-number']?>" >
                            <input type="hidden" name="profession" value="<?=@$_POST['applicant-profession']?>" >
                            <input type="hidden" name="message" value="<?=@$_POST['applicant-message']?>">
                            <div class="big-btn">
                                <button class="btn-three NoOfTicketbtn"> <span>Book Now</span></button>
                            </div>
                        </form>
                            </div>             
                          </div>
                        </div>        
                      </div>
                     
                    </div>
                  </div> 

           </div>
        </div>
     </section>


    <!-- footer -->
    <footer>
        <div class="container-fluid wrap">
            <!-- logo and social icon section -->
            <div class="row">
                <div class="col-lg-6 col-sm-6 col-sm-12 col-xs-12">
                    Copyright  © 2024 SKC.World. All Rights Reserved.
                </div>
                
            </div>
        </div>
    </footer>
    <style>
        .form_error{color:red; display: none;}
    </style>

    <script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
    <script>
        $(document).ready(function () {
            $("a").on('click', function (event) {
                if (this.hash !== "") {
                    event.preventDefault();
                    var hash = this.hash;
                    $('html, body').animate({
                        scrollTop: $(hash).offset().top
                    }, 1500, function () {
                        window.location.hash = hash;
                    });
                }
            });  
            
        });
    </script>

    
     <script>
      
   //Book Now toggle js
      $(document).ready(function(){
        
      
        
    //Book Now calculate price and quantity 
        
        // $(".NoOfTicket").change(function(){
        $(document).on('click change hover','.NoOfTicket,.NoOfTicketbtn',function(){  
            var TicketTypePrice="19500";
            var ticket=$('.NoOfTicket').val();
            var total=ticket*TicketTypePrice;
            
            
            total=total.toFixed(2);
            //$('#total').val(total); 
            //$('.total').html(' ');
            getTotle(total,ticket); 
            
             if($('.NoOfTicket').val()==''){
                $(".NoOfTicketbtn").attr('disabled', true);
            }else{
                $(".NoOfTicketbtn").attr('disabled', false);
            }
            //console.log(total);
        });
        
        $("#applyCoupan").click(function(){
            var coupan=$('#coupan').val();
            
            $.ajax({
              url: "ccav/coupan.txt",
              success: function (data){
                   
                   var lines = data.split("\n");
                    var queryArr=[];
                    $.each(lines, function(n, elem) {
                        var lines2 = elem.split(":");
                        //console.log(lines2[0]);
                        //queryArr[lines2[0]]=lines2[1];
                        if(coupan===lines2[0]){
                            var price=$('#total').val();
                            var discount=jQuery.trim(lines2[1]);
                            var total=price - (price * (discount / 100));
                            $('.coupan-msg').html(' ');
                            $('.coupan-msg').html('Apply Successfully');
                            $('.total').html('₹ '+price);
                            total=total.toFixed(2);
                            getTotle(total);
                            return false;
                        } else{
                            console.log(lines2[0]);
                            $('.coupan-msg').html(' ');
                            $('.coupan-msg').html('<span style="color:red">Coupon code is not valid<span>');
                        }
                    });
                    //console.log(queryArr);
                  //console.log(jQuery.inArray( "coupan", queryArr )  );
              }
            });
            
        });
        
      });
      
      function getTotle(total,ticket=''){
          $('.price-total .price-box span').html('');
          if(ticket){$('#fticket').val('');}
          $('#total').val('');
          
          $('.price-total .price-box span').html(total+'/-');
          if(ticket){$('#fticket').val(ticket);}
          $('#total').val(total);
          
          
      }
      
  
    </script>
</body>

</html>