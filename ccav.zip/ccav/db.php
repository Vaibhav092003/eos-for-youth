<?php
    $servername = "localhost";
    $username = "vidit018_anaavaran_workshop";
    $password = "anaavaran@123";
    $dbname = "vidit018_anaavaran_workshop";
    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    } 