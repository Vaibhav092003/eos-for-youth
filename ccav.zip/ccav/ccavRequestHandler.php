<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title> Custom Form Kit </title>
</head>
<body>
    <?php
  
    include('Crypto.php');
    include('db.php');
   	error_reporting(0);
   //error_reporting(E_ALL); ini_set('display_errors', 1);
    
   // $conn->close();

    if(isset($_POST)){
        $name = implode(",",$_POST['name']);
        $email = implode(",",$_POST['email']);
        $mobile = implode(",",$_POST['mobile']);
        $age = implode(",",$_POST['other_age']);
        $profession = implode(",",$_POST['other_profession']);
        //$gst_no = implode(",",$_POST['other_gst_no']);
        //$_POST['merchant_param1']='merchant_param1';
        $_POST['merchant_param2']=$name;
        $_POST['merchant_param3']=$email;
        $_POST['merchant_param4']=$mobile;
        $amt=$_POST['amount'];
        $billing_tel=$_POST['billing_tel'];
        $gst_no1=$_POST['gst_no'];
        $order_id=$_POST['order_id'];
        $tid=$_POST['tid'];
        
        $sql = "INSERT INTO `user_payment` (name, email, phone,age,profession,gst_no,order_id,tid,amount,currency,order_status,other_name,other_email,other_phone,other_age,other_profession)
        VALUES ('".$_POST['billing_name']."','".$_POST['billing_email']."','".$billing_tel."','".$_POST['age']."','".$_POST['profession']."','".$gst_no1."',$order_id,$tid,$amt,'".$_POST['currency']."','Success','".$name."', '".$email."', '".$mobile."', '".$age."', '".$profession."')";
        //print_r($sql);die;
        if ($conn->query($sql) === TRUE) {
            $last_id = $conn->insert_id;
            $_POST['tid']=$last_id;
            $_POST['order_id']='SKC-AnaavaranWorkshop-'.$last_id;
            $order_id2=$_POST['order_id'];
            $sql2 = "UPDATE user_payment SET tid=$last_id,order_id='".$order_id2."' WHERE id=$last_id";
            mysqli_query($conn, $sql2);
            if(!empty($last_id)){?>
                <center>
                <?php 
                	$merchant_data='79445';
                	$working_key='8EC904D5B2D4C6F0610EBEF0360343E5';//Shared by CCAVENUES
                	$access_code='AVUX86GF22CE04XUEC';//Shared by CCAVENUES
                	
                	foreach ($_POST as $key => $value){
                		$merchant_data.=$key.'='.urlencode($value).'&';
                	}
                	$encrypted_data=encrypt($merchant_data,$working_key); // Method for encrypting the data.
                //secure
                 //echo $last_id.'/'.$order_id2;exit();
                ?>
                <form method="post" name="redirect" action="https://secure.ccavenue.com/transaction/transaction.do?command=initiateTransaction"> 
                <?php
                echo "<input type=hidden name=encRequest value=$encrypted_data>";
                echo "<input type=hidden name=access_code value=$access_code>";
                ?>
                </form>
                </center>
                <script language='javascript'>document.redirect.submit();</script>


            <?php    
            }
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
        
    }
    ?>

</body>
</html>

